import { createEngine, draftHandle } from '@pkhex-everywhere/engine';
import './style.css';

const engine = createEngine();
const natureNames = ['がんばりや','さみしがり','ゆうかん','いじっぱり','やんちゃ','ずぶとい','すなお','のんき','わんぱく','のうてんき','おくびょう','せっかち','まじめ','ようき','むじゃき','ひかえめ','おっとり','れいせい','てれや','うっかりや','おだやか','おとなしい','なまいき','しんちょう','きまぐれ'];
let loaded = false;
let selectedSlot = null;
let selectedDetails = null;

const app = document.querySelector('#app');
app.innerHTML = `
  <header><div class="brand">PKHeX <span>JP</span></div><div class="sub">ポケモン セーブデータエディター</div></header>
  <main>
    <section class="panel intro"><h1>セーブデータ編集</h1><p>セーブデータはこのブラウザ内で処理されます。サーバーには送信しません。</p>
      <label class="file-button">セーブデータを読み込む<input id="saveFile" type="file" accept=".sav,.dsv,.dat,.bin,.main,.gci" /></label>
      <div id="status" role="status">エンジンを起動しています…</div>
    </section>
    <section id="savePanel" class="panel hidden"><div class="section-head"><h2>手持ちポケモン</h2><button id="export" class="primary">編集内容を書き出す</button></div><div id="party" class="party empty">セーブデータを読み込んでください。</div></section>
    <section id="editPanel" class="panel hidden"><h2>ポケモン編集</h2><div id="pokemonName" class="selected-name"></div>
      <label>ニックネーム<input id="nickname" maxlength="12" /></label>
      <label>レベル<input id="level" type="number" min="1" max="100" /></label>
      <label>性格<select id="nature"></select></label>
      <div class="actions"><button id="cancel" class="secondary">キャンセル</button><button id="apply" class="primary">変更を適用</button></div>
    </section>
    <p class="warning">試作版です。編集前に必ず元のセーブデータを複製してください。ROMハックのセーブは形式選択や互換性の問題が起こる場合があります。</p>
  </main>
  <footer>PKHeX.Core / PKHeX.Everywhere Engine</footer>`;

const status = document.querySelector('#status');
const partyEl = document.querySelector('#party');
const savePanel = document.querySelector('#savePanel');
const editPanel = document.querySelector('#editPanel');
const natureSelect = document.querySelector('#nature');
natureNames.forEach((name, i) => natureSelect.add(new Option(name, String(i))));

engine.onStatusChange?.(({state, loaded: bytes, total}) => {
  if (state === 'booting' && total) status.textContent = `編集エンジンを読み込み中… ${Math.round(bytes / total * 100)}%`;
  if (state === 'ready') status.textContent = 'エンジン準備完了。セーブデータを選択してください。';
  if (state === 'failed') status.textContent = 'エンジンの起動に失敗しました。通信環境を確認して再読み込みしてください。';
});
engine.ready.then(() => { status.textContent = 'エンジン準備完了。セーブデータを選択してください。'; }).catch(err => { status.textContent = `起動エラー：${err.message}`; });

function displayParty(party) {
  partyEl.innerHTML = '';
  if (!party?.length) { partyEl.textContent = '手持ちポケモンはいません。ボックス機能は今後追加予定です。'; return; }
  party.forEach((p, slot) => {
    const card = document.createElement('button');
    card.className = 'pokemon-card';
    const species = p.speciesName ?? p.name ?? (p.species != null ? `No.${p.species}` : '不明');
    card.innerHTML = `<strong>${escapeHtml(String(species))}</strong><span>Lv.${p.level ?? '－'}</span><small>タップして編集</small>`;
    card.addEventListener('click', () => openEditor(slot, species));
    partyEl.append(card);
  });
}
function escapeHtml(s) { return s.replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }

async function refreshParty() {
  const party = await engine.party.get();
  displayParty(party);
  savePanel.classList.remove('hidden');
}

document.querySelector('#saveFile').addEventListener('change', async e => {
  const file = e.target.files?.[0]; if (!file) return;
  status.textContent = `読み込み中：${file.name}`;
  try {
    await engine.game.load(file);
    loaded = true; selectedSlot = null; editPanel.classList.add('hidden');
    const game = await engine.game.get();
    status.textContent = `読み込み成功：${game?.versionName ?? game?.version ?? file.name}`;
    await refreshParty();
  } catch (err) {
    status.textContent = `読み込みエラー：${err.message}`;
  }
});

async function openEditor(slot, speciesLabel) {
  try {
    selectedSlot = slot;
    const handle = { source: 'party', slot };
    await engine.pokemon.edit(handle);
    selectedDetails = await engine.pokemon.details(draftHandle);
    document.querySelector('#pokemonName').textContent = speciesLabel;
    document.querySelector('#nickname').value = selectedDetails.nickname ?? '';
    document.querySelector('#level').value = selectedDetails.level ?? 1;
    natureSelect.value = String(selectedDetails.nature ?? 0);
    editPanel.classList.remove('hidden');
    editPanel.scrollIntoView({behavior:'smooth', block:'start'});
  } catch (err) { status.textContent = `編集画面エラー：${err.message}`; }
}

document.querySelector('#cancel').addEventListener('click', () => { selectedSlot = null; editPanel.classList.add('hidden'); });
document.querySelector('#apply').addEventListener('click', async () => {
  if (selectedSlot == null) return;
  const level = Number(document.querySelector('#level').value);
  if (!Number.isInteger(level) || level < 1 || level > 100) { status.textContent = 'レベルは1〜100で入力してください。'; return; }
  try {
    await engine.pokemon.update(draftHandle, { nickname: document.querySelector('#nickname').value, level, nature: Number(natureSelect.value) });
    await engine.pokemon.commit();
    editPanel.classList.add('hidden'); selectedSlot = null;
    status.textContent = '変更を適用しました。書き出すまでは元ファイルは変更されません。';
    await refreshParty();
  } catch (err) { status.textContent = `編集エラー：${err.message}`; }
});

document.querySelector('#export').addEventListener('click', async () => {
  if (!loaded) return;
  try {
    const {bytes, fileName} = await engine.game.export();
    const blob = new Blob([bytes], {type:'application/octet-stream'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = fileName || 'edited-save.sav'; a.click();
    setTimeout(() => URL.revokeObjectURL(url), 30000);
    status.textContent = '書き出しました。Deltaに戻す前にバックアップを保管してください。';
  } catch (err) { status.textContent = `書き出しエラー：${err.message}`; }
});

if ('serviceWorker' in navigator) window.addEventListener('load', () => navigator.serviceWorker.register('./sw.js').catch(() => {}));
