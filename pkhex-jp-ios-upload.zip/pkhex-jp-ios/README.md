# PKHeX JP iPhone Web App (prototype)

A Japanese-language mobile web prototype using `@pkhex-everywhere/engine`.

## Features in this prototype
- Load a supported Pokémon save file locally in the browser
- Display party Pokémon
- Edit party Pokémon nickname, level and nature
- Export the edited save file

## Important
- This is an experimental prototype, not a verified replacement for desktop PKHeX.
- Back up every save before editing.
- ROM hack formats may require explicit format selection and may not be supported.
- Save files are processed in the browser; do not upload save files to this public repository.
- The engine package is GPL-3.0-or-later. Review its license and comply with it before distributing modified builds.

## Deploy
The included GitHub Actions workflow builds with Vite and deploys to GitHub Pages.
