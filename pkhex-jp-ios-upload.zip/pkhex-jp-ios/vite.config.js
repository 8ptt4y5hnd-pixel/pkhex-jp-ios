import { defineConfig } from 'vite';
import pkhexEngine from '@pkhex-everywhere/engine/vite';

export default defineConfig({
  base: '/pkhex-jp-ios/',
  plugins: [pkhexEngine()],
  build: { outDir: 'dist' }
});
